
import '../demo_library.dart';
  
class TstEnum extends Enum<String> {
 
  const TstEnum(String val): super(val);
 
  static const TstEnum AAA = const TstEnum('AAA'); 
  static const TstEnum BBB = const TstEnum('BBB'); 
  static const TstEnum CCC = const TstEnum('CCC'); 
  static const TstEnum DDD = const TstEnum('DDD'); 	

  static const List values = const [TstEnum.AAA,TstEnum.BBB,TstEnum.CCC,TstEnum.DDD];
  static const Map selectMap = const {
    'AAA': 'AAA',
    'BBB': 'BBB',
    'CCC': 'CCC',
    'DDD': 'DDD',
  };

  static TstEnum valueOf(String val) {
    return values.firstWhere((e) => e.value == val, orElse: () => null);
  }

  Map toJson() {
    Map map = new Map();
    map["enumClass"] = "flca.demo.types.TstEnum";
    map["value"] = value;
    return map;
  }
} 
