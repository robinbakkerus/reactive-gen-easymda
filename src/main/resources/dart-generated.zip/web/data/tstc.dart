import '../demo_library.dart';
 
class Tstc extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String cname = null;
  Tsta tsta = null;
  Tstd d = null;
  Set<Tste> tstes = new Set();
  
  // constructor & factories
  Tstc() {}

  factory Tstc.clone(Tstc s) {
    Tstc r = new Tstc();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.cname = s.cname;
    r.tsta = s.tsta;
    r.d = s.d;
    r.tstes = s.tstes;
    return r;
  }

  factory Tstc.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tstc.fromMap(map);
  }

  factory Tstc.fromMap(map) {
    Tstc r = new Tstc();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.cname = map['cname'];
    var _tsta = map['tsta'];
    if (_tsta != null) {
       r.tsta = new Tsta.fromMap(_tsta);
    }
    var _d = map['d'];
    if (_d != null) {
       r.d = new Tstd.fromMap(_d);
    }
    List _tstes_list = map['tstes'];
    if (_tstes_list != null) {
      _tstes_list.forEach((e) => r.tstes.add(new Tste.fromMap(e)));
    }
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['cname'] = this.cname;
    map['tsta'] = this.tsta;
    map['d'] = this.d;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "cname=$cname,";
  }
} 