import '../demo_library.dart';

@CustomTag('main-header')
class MainHeader extends PolymerElement {

  MainHeader.created() : super.created() {
  }

}