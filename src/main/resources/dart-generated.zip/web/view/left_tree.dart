import '../demo_library.dart';

@CustomTag('left-tree')
class LeftTree extends PolymerElement {


  static List sServiceMethods = toObservable(['doSomething','helloWorld','ping','pingMe','saveTestA','searchTestA','getDto']);
  static List sDaoMethods = toObservable(['Tsta']);
  
  List serviceMethods = sServiceMethods;
  List daoMethods = sDaoMethods;
  
  void handleClick(MouseEvent e) {
    ButtonElement btn = e.currentTarget;
    var cmd = btn.text;
    Pubsub.publish(DemoConstants.EVENT_MENU_CLICK, cmd);
  }
  
  LeftTree.created() : super.created() {
  }

}
