import '../demo_library.dart';

import '../view/left_tree.dart';

class MainController {
  
  static MainController _instance = null;
  
  factory MainController() {
    if (_instance == null) _instance = new MainController._newInstance();  
    return _instance;
  }
  
  MainController._newInstance() {
    Pubsub.subscribe(DemoConstants.EVENT_MENU_CLICK, (PubsubMessage msg){
      _handleAction(msg.args[0]);
    });    
    
    // init the singleton controller to setup event listeners.
//    var dummy1 = new TestTstService();
    var dummy2 = new TstaCtrl();
  }
  
  void _handleAction(cmd) {
    if (isServiceCmd(cmd)) {
      Pubsub.publish(DemoConstants.TEST_SERVICE_ACTION, cmd);
    } else {
      switch(cmd) {
        case "Tsta" : 
          Pubsub.publish(DemoConstants.TSTA_FINDALL);
          break;
        default :
          window.alert("todo " + cmd);
      }
    }
   }
  
  bool isServiceCmd(cmd) {
    return LeftTree.sServiceMethods.contains(cmd);
  }
}
 