part of demo_library ;
  
class TstDto extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int dtoId = null;
  String dtoName = null;
  int count = 0;
  DateTime dob = null;
  
  // constructor & factories
  TstDto() {}

  factory TstDto.clone(TstDto s) {
    TstDto r = new TstDto();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.dtoId = s.dtoId;
    r.dtoName = s.dtoName;
    r.count = s.count;
    r.dob = s.dob;
    return r;
  }

  factory TstDto.fromJson(json) {
    Map map = JSON.decode(json);
    return new TstDto.fromMap(map);
  }

  factory TstDto.fromMap(map) {
    TstDto r = new TstDto();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.dtoId = map['dtoId'];
    r.dtoName = map['dtoName'];
    r.count = map['count'];
    r.dob = map['dob'];
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['dtoId'] = this.dtoId;
    map['dtoName'] = this.dtoName;
    map['count'] = this.count;
    map['dob'] = this.DateUtils.dateToJson(this.dob);
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "dtoId=$dtoId,dtoName=$dtoName,count=$count,dob=$dob,";
  }
} 