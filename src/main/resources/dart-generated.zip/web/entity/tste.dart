import '../demo_library.dart';
 
class Tste extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String ename = null;
  int ecount = 0;
  int tstcId = null;
  Set<Tstf> fs = new Set();
  
  // constructor & factories
  Tste() {}

  factory Tste.clone(Tste s) {
    Tste r = new Tste();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.ename = s.ename;
    r.ecount = s.ecount;
    r.tstcId = s.tstcId;
    r.fs = s.fs;
    return r;
  }

  factory Tste.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tste.fromMap(map);
  }

  factory Tste.fromMap(map) {
    Tste r = new Tste();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.ename = map['ename'];
    r.ecount = map['ecount'];
    r.tstcId = map['tstcId'];
    var _tstcId = map['tstcId'];
    if (_tstcId != null) {
       r.tstcId = new int.fromMap(_tstcId);
    }
    List _fs_list = map['fs'];
    if (_fs_list != null) {
      _fs_list.forEach((e) => r.fs.add(new Tstf.fromMap(e)));
    }
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['ename'] = this.ename;
    map['ecount'] = this.ecount;
    map['tstcId'] = this.tstcId;
    map['tstcId'] = this.tstcId;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "ename=$ename,ecount=$ecount,tstcId=$tstcId,";
  }
} 