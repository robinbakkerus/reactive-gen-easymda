
import '../../demo_library.dart';

class TstaDaoService extends DemoServiceBase {

  void findAllTsta(Function callback) {
    getData("findTsta", null, callback);
  }
  
  void retrieveTsta(String id, Function callback) {
    var args = "/" + id;
    getData("retrieveTsta", args, callback);
  }

  void saveTsta(Tsta data, Function callback) {
    postData("saveTsta", data, callback);
  }
}