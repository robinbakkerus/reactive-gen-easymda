import '../demo_library.dart';
 
class Tsta extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String name = null;
  DateTime dob = null;
  int count = 0;
  double salary = null;
  bool flag = false;
  TstEnum testEnum = null;
  String testLiteralAnno = null;
  Tstb b = null;
  Set<Tstc> tstcs = new Set();
  
  // constructor & factories
  Tsta() {}

  factory Tsta.clone(Tsta s) {
    Tsta r = new Tsta();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.name = s.name;
    r.dob = s.dob;
    r.count = s.count;
    r.salary = s.salary;
    r.flag = s.flag;
    r.testEnum = s.testEnum;
    r.testLiteralAnno = s.testLiteralAnno;
    r.b = s.b;
    r.tstcs = s.tstcs;
    return r;
  }

  factory Tsta.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tsta.fromMap(map);
  }

  factory Tsta.fromMap(map) {
    Tsta r = new Tsta();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.name = map['name'];
    r.dob = DateUtils.varToDate(map['dob']);
    r.count = map['count'];
    r.salary = map['salary'];
    r.flag = map['flag'];
    r.testEnum = TstEnum.valueOf(map['testEnum']['value']);
    r.testLiteralAnno = map['testLiteralAnno'];
    var _b = map['b'];
    if (_b != null) {
       r.b = new Tstb.fromMap(_b);
    }
    List _tstcs_list = map['tstcs'];
    if (_tstcs_list != null) {
      _tstcs_list.forEach((e) => r.tstcs.add(new Tstc.fromMap(e)));
    }
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['name'] = this.name;
    map['dob'] = DateUtils.dateToJson(this.dob);
    map['count'] = this.count;
    map['salary'] = this.salary;
    map['flag'] = this.flag;
    map['testEnum'] = this.testEnum;
    map['testLiteralAnno'] = this.testLiteralAnno;
    map['b'] = this.b;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "name=$name,dob=$dob,count=$count,salary=$salary,flag=$flag,testEnum=$testEnum,testLiteralAnno=$testLiteralAnno,";
  }
} 