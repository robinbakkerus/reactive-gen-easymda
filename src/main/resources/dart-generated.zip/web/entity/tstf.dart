import '../demo_library.dart';
 
class Tstf extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String fname = null;
  int fcount = 0;
  Tste tste = null;
  
  // constructor & factories
  Tstf() {}

  factory Tstf.clone(Tstf s) {
    Tstf r = new Tstf();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.fname = s.fname;
    r.fcount = s.fcount;
    r.tste = s.tste;
    return r;
  }

  factory Tstf.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tstf.fromMap(map);
  }

  factory Tstf.fromMap(map) {
    Tstf r = new Tstf();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.fname = map['fname'];
    r.fcount = map['fcount'];
    var _tste = map['tste'];
    if (_tste != null) {
       r.tste = new Tste.fromMap(_tste);
    }
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['fname'] = this.fname;
    map['fcount'] = this.fcount;
    map['tste'] = this.tste;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "fname=$fname,fcount=$fcount,";
  }
} 