
import '../../demo_library.dart';
  
@CustomTag('tsta-browse')
class TstaBrowse extends PolymerElement {
  
  @published @observable List columns;
  @published @observable List records;
  @published @observable Function clickEdit;
  
  TstaBrowse.created(): super.created() {
    this.columns = [
      {"key": "name", "title": "Name", "type": "string"},
      {"key": "dob", "title": "Dob", "type": "date"},
      {"key": "count", "title": "Count", "type": "number"},
      {"key": "salary", "title": "Salary", "type": "number"},
      {"key": "flag", "title": "Flag", "type": "boolean"},
      {"key": "testEnum", "title": "TestEnum", "type": "enum"},
      {"key": "testLiteralAnno", "title": "TestLiteralAnno", "type": "string"},    
    ];    
  }
} 
