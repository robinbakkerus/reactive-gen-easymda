import '../../demo_library.dart';
 
@CustomTag('tsta-form')
class TstaForm extends PolymerElement with AbstractForm {
  
  @override ShadowRoot get formRoot => shadowRoot;
           
  @override List<String> get fieldIds =>  ["#id_id","#id_name","#id_dob","#id_count","#id_salary","#id_flag","#id_testEnum","#id_testLiteralAnno","#id_b","#id_tstcs"];
  
  @observable
  Tsta _tsta;
  
  @observable 
  Tsta get tsta => _tsta;
  
  void set tsta(Tsta val) {
    _tsta = val;
    updateView();
  }
  
  TstaForm.created(): super.created() {} 
  
  @override Tsta updateModel() {
    Tsta r = new Tsta.clone(tsta);

    r.name = getValue('#id_name');
    r.dob = getValue('#id_dob');
    r.count = getValue('#id_count');
    r.salary = getValue('#id_salary');
    r.flag = getValue('#id_flag');
    r.testEnum = TstEnum.values[getSelectedIndex('#id_testEnum')];
    r.testLiteralAnno = getValue('#id_testLiteralAnno');    
    return r;
  }
  
  @override void updateView() {
  setValue('#id_id', tsta.id);    
    setValue('#id_name', tsta.name);  
    setValue('#id_dob', tsta.dob);  
    setValue('#id_count', tsta.count);  
    setValue('#id_salary', tsta.salary);  
    setValue('#id_flag', tsta.flag);  
    setCombobox("#id_testEnum", tsta.testEnum, TstEnum.values);
    setValue('#id_testLiteralAnno', tsta.testLiteralAnno);  
  }

  // observable Maps to populate combobox(s)
    @observable Map get testEnum_values => TstEnum.selectMap;      
  
} 

