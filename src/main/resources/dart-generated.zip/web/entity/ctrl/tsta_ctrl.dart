
import '../../demo_library.dart';

class TstaCtrl {

  static TstaCtrl _instance = null;

  TstaDaoService _tstaDaoService;

  factory TstaCtrl() {
    if (_instance == null) _instance = new TstaCtrl._newInstance();
    return _instance;
  }

  TstaCtrl._newInstance() {
    Pubsub.subscribe(DemoConstants.TSTA_FINDALL, (PubsubMessage msg) {
      _startBrowse();
    });
  }

  void _startBrowse() {
    tstaDaoService.findAllTsta(_handleFindAll);
  }

  void _onStartEdit(Event me, var detail, Node target) {
    DivElement div = target;
    print("index = " + div.id);
    tstaDaoService.retrieveTsta(div.id, _handleRetrieveTsta);
  }

  void _onDoSubmit(Tsta tsta) {
    tstaDaoService.saveTsta(tsta, _handleSaveTsta);
  }
  
  void _handleSaveTsta(data) {
//    print("_handleSaveTsta " + data);
    var tsta = new Tsta.fromJson(data);
    _showForm(tsta);
    print("_handleRetrieveTsta " + tsta.toString());
  }
  
  void _handleFindAll(data) {
    //    print("_handleFindAll " + data);
    _showGrid(data);
  }

  void _handleRetrieveTsta(data) {
    print("_handleRetrieveTsta " + data);
    var tsta = new Tsta.fromJson(data);
    _showForm(tsta);
    print("_handleRetrieveTsta " + tsta.toString());
  }

  void _showGrid(data) {
    TstaBrowse view = new Element.tag('tsta-browse');
    List<String> rows = JSON.decode(data);
    view.records = rows;
    view.clickEdit = _onStartEdit;
    MainView.instance().showContent(view);
  }

  void _showForm(tsta) {
    TstaForm view = new Element.tag('tsta-form');
    view.tsta = tsta;
    view.submitHandler = _onDoSubmit;
    MainView.instance().showContent(view);
  }

  TstaDaoService get tstaDaoService {
    if (_tstaDaoService == null) _tstaDaoService = new TstaDaoService();
    return _tstaDaoService;
  }
} 