import '../demo_library.dart';
 
class Tstd extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String dname = null;
  int daantal = 0;
  
  // constructor & factories
  Tstd() {}

  factory Tstd.clone(Tstd s) {
    Tstd r = new Tstd();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.dname = s.dname;
    r.daantal = s.daantal;
    return r;
  }

  factory Tstd.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tstd.fromMap(map);
  }

  factory Tstd.fromMap(map) {
    Tstd r = new Tstd();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.dname = map['dname'];
    r.daantal = map['daantal'];
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['dname'] = this.dname;
    map['daantal'] = this.daantal;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "dname=$dname,daantal=$daantal,";
  }
} 