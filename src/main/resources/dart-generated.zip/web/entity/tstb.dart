import '../demo_library.dart';
 
class Tstb extends Object with Observable {
  //properties
  List<int> ohc = [0];
  String fd = null;
  int id = null;
  String bname = null;
  int baantal = 0;
  int uniek = 0;
  
  // constructor & factories
  Tstb() {}

  factory Tstb.clone(Tstb s) {
    Tstb r = new Tstb();
    r.ohc = s.ohc;
    r.fd = s.fd;
    r.id = s.id;
    r.bname = s.bname;
    r.baantal = s.baantal;
    r.uniek = s.uniek;
    return r;
  }

  factory Tstb.fromJson(json) {
    Map map = JSON.decode(json);
    return new Tstb.fromMap(map);
  }

  factory Tstb.fromMap(map) {
    Tstb r = new Tstb();
    r.ohc = map['ohc'];
    r.fd = map['fd'];
    r.id = map['id'];
    r.bname = map['bname'];
    r.baantal = map['baantal'];
    r.uniek = map['uniek'];
    return r;
  }

  Map toJson() {
    Map map = new Map();
    map['id'] = this.id;
    map['bname'] = this.bname;
    map['baantal'] = this.baantal;
    map['uniek'] = this.uniek;
    //todo onetomany
    
    return map;
  }

  @override
  String toString() {
    return "id=$id,bname=$bname,baantal=$baantal,uniek=$uniek,";
  }
} 