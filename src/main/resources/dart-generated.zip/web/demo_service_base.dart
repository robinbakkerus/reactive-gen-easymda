import 'demo_library.dart';

abstract class DemoServiceBase {

  DemoServiceBase() {
  }

  var _host;
  
  String getHost() {
    if (_host == null) {
      int mode = DemoConstants.RUN_MODE;
      if (mode == DemoConstants.RUN_MODE_LOCAL) {
        _host = "../web/resources/json";
      } else if (mode == DemoConstants.RUN_MODE_TEST) { 
        //this url is based on the Corsa proxyserver. (> corsa --allow-proxy ALL --allow-origin ALL)
        _host = "http://localhost:${DemoConstants.PROXY_PORT}/proxy/http://localhost:${DemoConstants.HOST_PORT}";   
      } else {
        _host = "localhost:${DemoConstants.HOST_PORT}" ;
      }
    }
    return _host;
  }

  void getData(action, args, callback) {
    var request = HttpRequest.getString(getUrl(action, args)).then(callback);
  }
  
 
  void postData(action, obj, callback) {
    if (DemoConstants.RUN_MODE == DemoConstants.RUN_MODE_LOCAL) {
      print("json = " + JSON.encode(obj));
      getData(action, null, callback);
    } else {
      var request = new HttpRequest();
      request.onReadyStateChange.listen(callback);
      request.open("GET", getUrl(action, null));
      request.send(JSON.encode(obj));
    }
  }

  String getUrl(String action, String args) {
    var url;
    if (DemoConstants.RUN_MODE == DemoConstants.RUN_MODE_LOCAL) {
      url = getHost() + "/" + action + ".json";
    } else {
      url = getHost() + "/" + action;
      if (args != null) {
        url += args;
      }
    }
    return url;
  }
}