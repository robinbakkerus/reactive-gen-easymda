abstract class DemoConstants {
  
  static const HOST_PORT = 8000;
  static const PROXY_PORT = 8888;
  
  static const RUN_MODE_PROD = 0; //use the backend url
  static const RUN_MODE_LOCAL = 1; //use generated json files under resources/json
  static const RUN_MODE_TEST = 2; //use a proxy server to overcome cors headers (ex: corsa)

  static const RUN_MODE = RUN_MODE_LOCAL;
   
  static const EVENT_MENU_CLICK = "EVENT_MENU_CLICK";
  static const TEST_SERVICE_ACTION = "TEST_SERVICE_ACTION";

  // @GENERATED constants
   static const TSTA_REMOVE_SUCCESS = "TSTA_REMOVE_SUCCESS";
     static const TSTA_SAVE_SUCCESS = "TSTA_SAVE_SUCCESS";
     static const TSTA_SEARCH_ERROR = "TSTA_SEARCH_ERROR";
     static const TSTA_RETRIEVE = "TSTA_RETRIEVE";
     static const TSTA_RETRIEVE_ERROR = "TSTA_RETRIEVE_ERROR";
     static const TSTA_FINDALL_ERROR = "TSTA_FINDALL_ERROR";
     static const TSTA_SAVE_ERROR = "TSTA_SAVE_ERROR";
     static const TSTA_FINDALL_SUCCESS = "TSTA_FINDALL_SUCCESS";
     static const TSTA_RETRIEVE_SUCCESS = "TSTA_RETRIEVE_SUCCESS";
     static const TSTA_REMOVE_ERROR = "TSTA_REMOVE_ERROR";
     static const TSTA_SAVE = "TSTA_SAVE";
     static const TSTA_EDIT = "TSTA_EDIT";
     static const TSTA_FINDALL = "TSTA_FINDALL";
     static const TSTA_SEARCH = "TSTA_SEARCH";
     static const TSTA_SEARCH_SUCCESS = "TSTA_SEARCH_SUCCESS";
     static const TSTA_ADD = "TSTA_ADD";
     static const TSTA_REMOVE = "TSTA_REMOVE";
     static const TSTA_SHOW_GRID = "TSTA_SHOW_GRID";
     static const TSTA_CLOSE_DETAIL = "TSTA_CLOSE_DETAIL";
     static const TSTA_REMOVE_DETAIL = "TSTA_REMOVE_DETAIL";
     static const TSTA_REMOVE_GRID = "TSTA_REMOVE_GRID";
     static const TSTA_SHOW_DETAIL = "TSTA_SHOW_DETAIL";
}
