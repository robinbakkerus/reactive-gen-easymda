 
import '../demo_library.dart';

class TstService extends DemoServiceBase {
  
    void doSomething(Function callback) { 
       getData("doSomething", null, callback);
    }
      
    void helloWorld(Function callback) { 
       getData("helloWorld", null, callback);
    }
       
    void ping(aMessage, Function callback) { 
       getData("ping", aMessage, callback);
    }
        
    void pingMe(aMessage1, aMessage2, Function callback) { 
       getData("pingMe", aMessage1, aMessage2, callback);
    }
       
    void saveTestA(aValue, Function callback) { 
       getData("saveTestA", aValue, callback);
    }
       
    void searchTestA(aName, Function callback) { 
       getData("searchTestA", aName, callback);
    }
       
    void getDto(aValue, Function callback) { 
       getData("getDto", aValue, callback);
    }
    
}