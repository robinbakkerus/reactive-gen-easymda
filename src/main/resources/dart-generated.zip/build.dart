import 'package:polymer/builder.dart';
        
main(args) {
  build(entryPoints: ['web/main.html'],
        options: parseOptions(args));
}
