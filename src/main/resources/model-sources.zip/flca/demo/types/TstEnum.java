package flca.demo.types;

public enum TstEnum  {

	AAA,
	BBB,
	CCC,
	DDD,
}
