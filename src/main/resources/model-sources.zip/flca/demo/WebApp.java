package flca.demo;

import mda.type.IApplicationType;

public class WebApp implements IApplicationType {

	@Override
	public String getBasePackage() {
		return this.getClass().getPackage().getName();
	}

	@Override
	public String getRestBaseUrl() {
		return "/rest";
	}
	
}
