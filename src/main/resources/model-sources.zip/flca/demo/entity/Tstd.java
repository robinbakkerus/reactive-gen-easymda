package flca.demo.entity;

import mda.type.IEntityType;

public class Tstd implements IEntityType
{
	String dname;
	int daantal;
	
}
