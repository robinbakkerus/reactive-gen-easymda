package flca.demo.errors;

public class TstException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6009994650593305908L;

	
}
