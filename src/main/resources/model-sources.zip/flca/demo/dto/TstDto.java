package flca.demo.dto;

import java.util.Date;

import mda.type.IDtoType;

public class TstDto implements IDtoType {

	Long dtoId;
	String dtoName;
	int count;
	Date dob;
}
